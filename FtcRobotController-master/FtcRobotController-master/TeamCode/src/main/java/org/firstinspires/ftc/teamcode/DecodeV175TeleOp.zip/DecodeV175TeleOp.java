package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Gamepad;

import org.firstinspires.ftc.teamcode.mech.ColorSensor;
import org.firstinspires.ftc.teamcode.mech.IntakeV175;
import org.firstinspires.ftc.teamcode.mech.MecanumDrive;
import org.firstinspires.ftc.teamcode.mech.Limelight;

//this is a new version for the new intake system;
//didnt want to deal with the mess of forgetting how i did something

@TeleOp(name="DecodeV175TeleOp", group="Iterative OpMode")
public class DecodeV175TeleOp extends OpMode {
    MecanumDrive chassis = null;
    IntakeV175 cannon = null;
    ColorSensor colSens = null;
    //private Gamepad currGP2 = new Gamepad();
    //private Gamepad prevGP2 = new Gamepad();


    ColorSensor.detectedColor detectedColor;


    private boolean dPadUpPressed;
    private boolean dPadDownPressed;
    private boolean oldDPadUpPressed;
    private boolean oldDPadDownPressed;
    private boolean rStickPressed;
    private boolean oldrStickPressed;

    private boolean aPressed;
    private int oldAPressed;
    private double leftX;
    private double leftY;
    private double rightX;


    @Override
    public void init(){
        chassis = new MecanumDrive(hardwareMap);
        cannon = new IntakeV175(hardwareMap);
        colSens = new ColorSensor(hardwareMap);
        //chassis.resetRobotAngle();//should be commented out to run teleOp after Auto & keep angle
    }

    @Override
    public void loop(){
        dPadUpPressed = gamepad2.dpad_up;

        //controlled turning
        rStickPressed = gamepad1.right_stick_button;
        oldrStickPressed = rStickPressed;

        dPadDownPressed = gamepad2.dpad_down;
        oldDPadDownPressed = dPadDownPressed;
        oldDPadUpPressed = dPadUpPressed;

        aPressed = gamepad2.a;
        //oldAPressed = 0;

        leftX = gamepad1.left_stick_x;
        leftY = gamepad1.left_stick_y;
        rightX = gamepad1.right_stick_x;

        //intake wheel begin
        if (aPressed /*&& oldAPressed == 0*/){
           cannon.intake(1);
           //oldAPressed++;
        }
        if (aPressed /*&& oldAPressed == 1*/){ //this should be the off

            //oldAPressed--;
            //cannon.gate(0); //needs servo
        }
        if (gamepad2.b){
            cannon.intake(0); //mooved here temp

            //cannon.gate(.5); //needs servo
        }
        if (gamepad2.x) {
            cannon.launch(1);//.13
        }
        if (gamepad2.y) {
            cannon.stopLaunch();
        }

        /*if (dPadDownPressed && !oldDPadDownPressed) {
            cannon.intake(-.5);
            oldDPadDownPressed = true;
        }
        if (dPadDownPressed && oldDPadDownPressed){
            cannon.intake(0);
            oldDPadDownPressed = false;
        }*/

        if(gamepad2.dpad_down){
            cannon.intake(-.1);
        }
        //intake wheel end

       /* if(gamepad2.dpad_right){
            cannon.launchSmarter(true);
        }
        */


        //angle recognition end

        // (FI) color sensor begin
        detectedColor = colSens.getDetectedColor(telemetry);
        // color sensor end


        //controlled drive begin not finished
/*
        if (rStickPressed && !oldrStickPressed) {
            leftX = leftX/1.5;
            leftY = leftY/1.5;
            rightX = rightX/1.5;
            oldrStickPressed = true;
        }

        if (rStickPressed && oldrStickPressed){
            chassis.drive(-gamepad1.left_stick_y, gamepad1.left_stick_x, gamepad1.right_stick_x / 1.5);
            oldrStickPressed = false;

        }
        */
        //Slow turn code :D
        if (gamepad1.right_bumper){
            chassis.slowTurn(0.1);
        }
        else if(gamepad1.left_bumper){
            chassis.slowTurn(-0.1);
        }
        else {
            chassis.drive(-leftY, leftX, rightX);
        }

        //chassis.setLightColor();

        //cannon.launchSmarter(gamepad2.right_bumper);

        colSens.getDetectedColor(telemetry);
        telemetry.addData("aPressed: ", aPressed);
        telemetry.addData("Was a pressed before?: ", oldAPressed);
        telemetry.addData("Methinks the color is", detectedColor);
        telemetry.addData("stick pressed", rStickPressed);
        telemetry.addData("did it stick", oldrStickPressed);
        telemetry.addData("Launcher Velocity", cannon.getLauncherVelocity());
        telemetry.addData("Launch Angle", chassis.getLaunchAngle());
        telemetry.addData("IMU", chassis.getRobotAngle());
        //telemetry.addData();
        telemetry.update();
    }


}
